export default function Header() {
  return <header><h1>Demo Project</h1></header>
}
