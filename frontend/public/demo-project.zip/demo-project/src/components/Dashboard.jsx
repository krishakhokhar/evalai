export default function Dashboard() {
  return <main><p>Dashboard content</p></main>
}
