import Header from './components/Header.jsx'
import Dashboard from './components/Dashboard.jsx'
export default function App() {
  return (
    <div>
      <Header />
      <Dashboard />
    </div>
  )
}
