# Demo Project

A small React app for the EvalAI demo.

## Setup

1. `npm install`
2. `npm run dev`
3. Open http://localhost:5173

## Build

`npm run build` outputs to `dist/`.
